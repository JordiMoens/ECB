library(knitr)
library(kableExtra)
library(PerformanceAnalytics)
library(tidyverse)
library(DescTools)
library(xts)
library(readxl)
library(tidyverse)

# Import all data

load("/Users/mattiesdefrenne/Documents/1. UA FBE/Msc. Financial Engineering/Sem 2/Empirical Finance Lab/Assignments/Assignment 15 Brown/RI_UK.RData")

# Remove stocks that are not yet on the market at the beginning for easier computations later on
date <- RI.all[,1]
column.names <- colnames(RI.all)
RI.names <- column.names[-grep("DEAD",x = column.names, ignore.case = T)]
RI.all <- RI.all[, RI.names]
#write.xlsx(RI.all, file = "UKfiltered.xlsx", sheetName = "RI")


RI.xts <- as.xts(RI.all[,-1], order.by = RI.all[,1])
R <-diff(RI.xts, arithmetic = F, na.pad = F) - 1
R <- R["2010/2020"]
R <- R[ , apply(R, 2, function(x) !any(is.na(x)))]

# If always the same stocks 

nSim <- 1000

Simulation <- function(R, adjustment){
  
  stocks <- R[,sample(dim(R)[2], 50, replace = T)]
  
  # Make coredata because xts fucks up alignment on dates
  returns <- coredata(stocks)
  
  # Select event dates, but constraints have to be made because you need at least 
  # Last 10 days have to be left alone, and need minimum 245 days before the date to compute differences.
  max.date <- dim(returns)[1] - 10 - 244
  event.dates <- sample(max.date, 50, replace = T) + 244
  
  # Extract all event periods
  extracted.periods <- matrix(nrow = 250, ncol = 50)
  
  for (i in 1:length(event.dates)) {
    extracted.periods[,i] <- returns[(event.dates[i]-244):(event.dates[i]+5),i]
  }
  
  nrows <-  dim(extracted.periods)[1]
  # Mean-Adjusted Returns
  mean.AR <- sapply(as.data.frame(extracted.periods), FUN = function(x) x - mean(x[1:(nrows-11)]))
  mean.AR[dim(mean.AR)[1]-5,] <- mean.AR[dim(mean.AR)[1]-5,] + adjustment
  
  # Market Adjusted Returns
  market.returns <- colMeans(t(extracted.periods))
  market.AR <- sweep(x = extracted.periods, MARGIN = 1, STATS = market.returns)
  market.AR[dim(mean.AR)[1]-5,] <- market.AR[dim(market.AR)[1]-5,] + adjustment
  # OLS Market model
  OLS.AR <- sapply(as.data.frame(extracted.periods), FUN = function(x) x - lm(x[1:(nrows-11)] ~ market.returns[1:(nrows-11)])$coef[1] - 
                                            lm(x[1:(nrows-11)] ~ market.returns[1:(nrows-11)])$coef[2]*market.returns)
  OLS.AR[dim(OLS.AR)[1]-5,] <- OLS.AR[dim(OLS.AR)[1]-5,] + adjustment
  
  
  # Computation of T statistics
  # Mean-adjusted
  means.MeanAR <- colMeans(t(mean.AR[1:(nrows-11),]))
  t.mean.AR <- mean(mean.AR[dim(mean.AR)[1]-5,])/sd(means.MeanAR)
  
  means.MarketAR <- colMeans(t(market.AR[1:(nrows-11),]))
  t.market.AR <- mean(market.AR[dim(market.AR)[1]-5,])/sd(means.MarketAR)
  
  means.OLSAR <- colMeans(t(OLS.AR[1:(nrows-11),]))
  t.OLS.AR <- mean(OLS.AR[dim(OLS.AR)[1]-5,])/sd(means.OLSAR)
  
  return(list(mean.adjusted = t.mean.AR, market.adjusted = t.market.AR, OLS = t.OLS.AR))
}
test <- Simulation(R = R,0)
test$mean.adjusted
test$market.adjusted
test$OLS
# Simulation replication:
adjustment.0 <- replicate(1000,Simulation(R,0))
adjustment.005 <- replicate(1000,Simulation(R,0.005))
adjustment.01 <- replicate(1000,Simulation(R,0.01))
adjustment.02 <- replicate(1000,Simulation(R,0.02))

critical.value <- qt(0.95, df = 1000)

table <- as.data.frame(cbind(colMeans(t(adjustment.0)>critical.value),
                             colMeans(t(adjustment.005)>critical.value),
                             colMeans(t(adjustment.01)>critical.value),
                             colMeans(t(adjustment.02)>critical.value)))
colnames(table) <- c("0","0.005","0.01","0.02")
rownames(table) <- c("Mean adjusted returns", "Market adjusted returns", "OLS Market model")

kable(round(100*table,2), booktabs = T, 
      caption = "\\label{table}A comparison of different procedures for detecting abnormal performance: percentage of 1000 samples where the null hypothesis is rejected. H0: mean abnormal performance at day '0'=0 .") %>%
  add_header_above(c(" "= 1, "Actual level of Abnormal Performance at day 0" = 4)) %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed", "responsive"), full_width = FALSE) %>%
  column_spec(column = 1, bold = T)


